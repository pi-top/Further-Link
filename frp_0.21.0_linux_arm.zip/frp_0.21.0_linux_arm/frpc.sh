#!/bin/bash
nohup /usr/local/frp/frpc -c /etc/frp.ini &
